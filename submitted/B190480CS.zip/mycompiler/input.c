read(argc);
argc=FUN(argc){
	x=3;
	X=4;
	If ( x <= X ) {
		write(x);
		a=12;
		return 2;
	} else {
		write(X);
		b=15;
		return 4;
	}
	return x;
}
write(argc);
