Create final xsm file named B190480CS

make input=filename.txt


make build --> to rebuild all executables

make clean --> to clean executables and intermidiate files 
